<?php
namespace App;
class DateTime {
public $name = "Hello";
};

?>