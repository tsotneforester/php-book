<?php
require 'DateTime.php';

use App\DateTime as Mydatetime;

$obj1 = new DateTime; //will run builtin DateTime class
$obj2 = new Mydatetime; //will run custom DateTime class

print_r($obj1);//DateTime Object ( [date] => 2022-07-08 15:16:44.759547 [timezone_type] => 3 [timezone] => Europe/Berlin )
print_r($obj2);//App\DateTime Object ( [name] => Hello )
?>