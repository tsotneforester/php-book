<?php

			class Product {


			};

      
      ?>