<?php
spl_autoload_register(function($class) {
      require "$class.php";
    });
    
    $product = new Product;
    $region = new Region;
    
    var_dump($product); //object(Product)#2 (0) { }
    var_dump($region); //object(Region)#3 (0) { }
          



?>