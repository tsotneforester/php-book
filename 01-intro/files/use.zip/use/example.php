<?php
require 'item.php';
use App\Utils\item;
use const App\Utils\MAX;
use function app\Utils\sayHello;

$obj = new Item;
echo MAX;//100
sayHello();//Hello
?>