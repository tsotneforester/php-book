<?php
namespace App\Utils;
class item {};
const MAX = 100;
function sayHello() {
echo "Hello";
}
?>