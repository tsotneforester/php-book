<?php
spl_autoload_register(function($class) {
      require str_replace('\\', '/', $class) . ".php";
    });
    

// require 'Product\Product.php';
// require 'Region\Region.php';

    $product = new Product\Product;
    $region = new Region\Region;
    
    var_dump($product); //object(Product\Product)#2 (0) { }
    var_dump($region); //object(Region\Region)#3 (0) { }
          



?>