<?php
namespace Product;
			class Product {


			};
?>