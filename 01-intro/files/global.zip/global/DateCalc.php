<?php
namespace App;
// use DateTime;
class DateCalc {
public function getToday() {
$dt = new DateTime;
//$dt = new \DateTime;
return $dt->format('l');
}
};

?>