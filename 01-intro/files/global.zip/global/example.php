<?php
require 'DateCalc.php';
$calc = new App\DateCalc;
echo $calc->getToday();
?>